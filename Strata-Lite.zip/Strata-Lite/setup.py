#!/usr/bin/env python3
"""Strata Lite - 轻量本地大模型启动器（只用 Python 标准库）。
首次运行：检测硬件 -> 提问 -> 下载 llama.cpp 与模型 -> 启动。之后运行：直接启动。"""
import argparse, ctypes, json, os, re, shutil, socket, subprocess, sys, time, urllib.error, urllib.request, webbrowser, zipfile
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace"); sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

ROOT = Path(__file__).resolve().parent
ENGINE, MODELS, RUN, LOGS = ROOT / "engine", ROOT / "models", ROOT / "run", ROOT / "logs"
CFG = ROOT / "config.json"
HF = os.environ.get("HF_ENDPOINT", "https://huggingface.co").rstrip("/")
UA = {"User-Agent": "strata-lite/1.0"}
WIN = os.name == "nt"

# 权重大小为 Q4_K_M 的大致值（GB）。Qwen3.5 系列原生多模态、可开关思考。
TIERS = {
    "mini":   dict(repo="unsloth/Qwen3.5-2B-GGUF", gb=1.4, ctx=16384, desc="极省：约 1.5GB 显存，随便和 ComfyUI/游戏同开"),
    "small":  dict(repo="unsloth/Qwen3.5-4B-GGUF", gb=2.8, ctx=16384, desc="均衡：约 3GB 显存，可与 ComfyUI 同开"),
    "medium": dict(repo="unsloth/Qwen3.5-9B-GGUF", gb=5.7, ctx=8192,  desc="最强：约 6-7GB 显存，8GB 卡独占运行"),
}
DEFAULT = dict(tier=None, repo=None, gguf=None, vision="auto", ctx=None, think=False, idle=600, host="127.0.0.1",
               port=8080, api_key="", threads=4, kv="q8_0", coexist=False, budget=4096, files={})

def say(*a): print(*a, flush=True)
def ok(m): say(f"  [OK] {m}")
def warn(m): say(f"  [!]  {m}")
def die(m, hint=""):
    say(f"\n  [X] {m}")
    if hint: say(f"      {hint}")
    sys.exit(1)

# ---------------------------------------------------------------- 硬件
def run(cmd, timeout=20):
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, encoding="utf-8", errors="replace")
        return (r.stdout or "") + (r.stderr or "" if "--help" in cmd else "")
    except Exception:
        return ""

def gpu_info():
    out = run(["nvidia-smi", "--query-gpu=name,memory.total,memory.free,driver_version", "--format=csv,noheader,nounits"])
    if not out.strip(): return None
    try:
        n, t, f, d = [x.strip() for x in out.strip().splitlines()[0].split(",")]
        cu = re.search(r"CUDA Version:\s*(\d+)\.(\d+)", run(["nvidia-smi"]))
        return dict(name=n, total=float(t) / 1024, free=float(f) / 1024, driver=d, cuda=(int(cu[1]), int(cu[2])) if cu else None)
    except Exception:
        return None

def ram_gb():
    """(总内存, 可用内存) GB"""
    if WIN:
        class MS(ctypes.Structure):
            _fields_ = [("l", ctypes.c_ulong), ("load", ctypes.c_ulong)] + [(n, ctypes.c_ulonglong) for n in ("tp", "ap", "tpf", "apf", "tv", "av", "ae")]
        m = MS(); m.l = ctypes.sizeof(m)
        ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m))
        return m.tp / 2**30, m.ap / 2**30
    try:
        kv = {l.split(":")[0]: int(l.split()[1]) for l in open("/proc/meminfo")}
        return kv["MemTotal"] / 2**20, kv["MemAvailable"] / 2**20
    except Exception:
        return 0.0, 0.0

def recommend(gpu, coexist):
    if not gpu: return "mini"
    free = gpu["free"]
    if coexist: return "small" if free >= 4.0 else "mini"
    return "medium" if free >= 7.0 else "small" if free >= 3.8 else "mini"

# ---------------------------------------------------------------- 下载
def http_json(url):
    with urllib.request.urlopen(urllib.request.Request(url, headers=UA), timeout=30) as r:
        return json.load(r)

def download(url, dest, expected=None, label=""):
    dest = Path(dest); dest.parent.mkdir(parents=True, exist_ok=True)
    if dest.exists() and (expected is None or dest.stat().st_size == expected): return
    part = dest.with_name(dest.name + ".part")
    for attempt in range(1, 9):
        have = part.stat().st_size if part.exists() else 0
        if expected and have == expected: break
        try:
            h = dict(UA); 
            if have: h["Range"] = f"bytes={have}-"
            with urllib.request.urlopen(urllib.request.Request(url, headers=h), timeout=30) as r:
                if have and r.status == 200: have = 0          # 服务器不支持续传，重来
                total = expected or (int(r.headers.get("Content-Length", 0)) + have)
                t0, got = time.time(), 0
                with open(part, "ab" if have else "wb") as f:
                    while True:
                        b = r.read(1 << 20)
                        if not b: break
                        f.write(b); got += len(b)
                        cur = have + got
                        sp = got / max(time.time() - t0, 1e-3) / 2**20
                        pct = f"{cur * 100 / total:5.1f}%" if total else ""
                        print(f"\r  下载 {label} {cur / 2**30:5.2f}/{total / 2**30:5.2f} GB {pct} {sp:5.1f} MB/s   ", end="", flush=True)
            print()
            break
        except urllib.error.HTTPError as e:
            if e.code == 416 and part.exists(): break
            warn(f"下载出错 {e}，重试 {attempt}/8"); time.sleep(3)
        except Exception as e:
            print(); warn(f"网络中断（{e}），重试 {attempt}/8"); time.sleep(3)
    else:
        die(f"下载失败：{label}", "检查网络后重新运行即可断点续传；国内可先设置环境变量 HF_ENDPOINT=https://hf-mirror.com")
    if expected and part.stat().st_size != expected:
        die(f"文件大小不对：{label}", f"删除 {part} 后重试")
    part.replace(dest)

def hf_files(repo):
    try:
        tree = http_json(f"{HF}/api/models/{repo}/tree/main")
    except Exception as e:
        die(f"无法读取模型仓库 {repo}：{e}", "检查网络/镜像，或用 --repo 指定其它 GGUF 仓库")
    return {t["path"]: t.get("size", 0) for t in tree if t.get("type") == "file"}

def pick_gguf(files):
    for pat in (r"-Q4_K_M\.gguf$", r"UD-Q4_K_XL\.gguf$", r"Q4_K_S\.gguf$", r"Q4_.*\.gguf$"):
        c = [n for n in files if re.search(pat, n) and "mmproj" not in n.lower() and "/" not in n]
        if c: return sorted(c)[0]
    return None

def pick_mmproj(files):
    for n in ("mmproj-F16.gguf", "mmproj-BF16.gguf", "mmproj-F32.gguf"):
        if n in files: return n
    c = [n for n in files if n.lower().startswith("mmproj")]
    return sorted(c)[0] if c else None

def pick_llama_assets(assets, cuda):
    """从 llama.cpp 发布包里选：驱动支持的最高 CUDA 版本 -> Vulkan -> CPU"""
    names = {a["name"]: a["browser_download_url"] for a in assets if a["name"].endswith(".zip")}
    win = [n for n in names if "win" in n.lower() and "x64" in n.lower()]
    def ver(n):
        m = re.search(r"cuda-(\d+)\.(\d+)", n.lower()); return (int(m[1]), int(m[2])) if m else None
    main = [n for n in win if not n.lower().startswith("cudart")]
    if cuda:
        c = sorted([(ver(n), n) for n in main if ver(n) and ver(n) <= cuda])
        if c:
            v, n = c[-1]
            rt = [x for x in win if x.lower().startswith("cudart") and ver(x) == v]
            return [names[n]] + [names[r] for r in rt], n
    for key in ("vulkan", "cpu"):
        c = [n for n in main if key in n.lower()]
        if c: return [names[c[0]]], c[0]
    if main:                                      # 兜底：实在没匹配上就拿第一个 win/x64 包，好过直接失败
        return [names[main[0]]], main[0]
    say("    可用文件：" + ", ".join(sorted(names)) or "（空）")
    return None, None

def ensure_engine(gpu, force=False):
    tagf = ENGINE / "version.txt"
    if not force and list(ENGINE.rglob("llama-server*")) and tagf.exists():
        return
    if not WIN:
        die("自动安装目前只支持 Windows", "Linux 请自行安装 llama.cpp，并把 llama-server 放进 engine/ 目录")
    say("  正在获取最新的 llama.cpp ...")
    try:
        # llama.cpp 的所有发布都标记为 "pre-release"，/releases/latest 拿不到，改用列表取第一个（最新）
        rels = http_json("https://api.github.com/repos/ggml-org/llama.cpp/releases?per_page=5")
        rel = rels[0]
    except Exception as e:
        die(f"无法访问 GitHub：{e}", "检查网络/代理后重试；也可手动下载 llama.cpp 的 Windows 包解压到 engine/ 目录")
    urls, name = pick_llama_assets(rel["assets"], gpu["cuda"] if gpu else None)
    if not urls: die("没有找到适合 Windows 的 llama.cpp 发布包")
    ok(f"引擎：{rel['tag_name']} / {name}")
    if ENGINE.exists(): shutil.rmtree(ENGINE)
    ENGINE.mkdir(parents=True)
    for u in urls:
        z = ENGINE / u.rsplit("/", 1)[1]
        download(u, z, label=z.name[:30])
        with zipfile.ZipFile(z) as zf: zf.extractall(ENGINE)
        z.unlink()
    tagf.write_text(rel["tag_name"])

def server_exe():
    c = list(ENGINE.rglob("llama-server.exe")) or list(ENGINE.rglob("llama-server"))
    return c[0] if c else None

# ---------------------------------------------------------------- 配置
def load_cfg():
    c = dict(DEFAULT)
    if CFG.exists():
        try: c.update(json.loads(CFG.read_text(encoding="utf-8")))
        except Exception: warn("config.json 损坏，已忽略")
    return c

def save_cfg(c): CFG.write_text(json.dumps(c, ensure_ascii=False, indent=2), encoding="utf-8")

def ask(q, choices, default, yes=False):
    if yes: return default
    while True:
        r = input(f"  {q} [{'/'.join(choices)}] (默认 {default}): ").strip().lower() or default
        if r in choices: return r
        say("    请输入其中之一")

def interview(cfg, gpu, a):
    say("\n[2/4] 几个问题（直接回车 = 推荐）")
    cfg["coexist"] = ask("需要和 ComfyUI / 游戏同时运行吗？", ["y", "n"], "y" if cfg["coexist"] else "n", a.yes) == "y"
    rec = recommend(gpu, cfg["coexist"])
    if not (cfg["repo"] or cfg["gguf"]):
        say("")
        for i, (k, t) in enumerate(TIERS.items(), 1): say(f"    {i}) {k:6s} {t['desc']}{'   <- 推荐' if k == rec else ''}")
        idx = ask("选哪个档位？", ["1", "2", "3"], str(list(TIERS).index(rec) + 1), a.yes)
        cfg["tier"] = list(TIERS)[int(idx) - 1]
    cfg["vision"] = ask("需要看图（图片理解）吗？auto=需要时自动决定放 CPU 还是 GPU", ["auto", "gpu", "cpu", "off"], cfg["vision"], a.yes)
    dm = str(cfg["idle"] // 60)
    cfg["idle"] = int(ask("空闲多少分钟后自动卸载模型释放显存？(0=不卸载)", ["0", "5", "10", "30"], dm if dm in ("0", "5", "10", "30") else "10", a.yes)) * 60
    cfg["think"] = ask("默认开启思考模式？（更聪明但更慢更费算力）", ["y", "n"], "y" if cfg["think"] else "n", a.yes) == "y"

# ---------------------------------------------------------------- 启动
def build_cmd(cfg, exe, model, mmproj, help_text):
    sup = lambda f: f in help_text
    tier = TIERS.get(cfg["tier"] or "", {})
    ctx = cfg["ctx"] or tier.get("ctx", 8192)
    cmd = [str(exe), "-m", str(model), "--host", cfg["host"], "--port", str(cfg["port"]), "-c", str(ctx),
           "-ngl", "99", "-np", "1", "--jinja", "-b", "512", "-ub", "512", "-t", str(cfg["threads"])]
    cmd += ["-fa", "on"] if "on|off|auto" in help_text else (["-fa"] if sup("--flash-attn") else [])
    if cfg["kv"] != "f16" and sup("--cache-type-k"): cmd += ["-ctk", cfg["kv"], "-ctv", cfg["kv"]]
    if sup("--cache-ram"): cmd += ["--cache-ram", "512"]
    if cfg["idle"] and sup("--sleep-idle-seconds"): cmd += ["--sleep-idle-seconds", str(cfg["idle"])]
    if mmproj:
        cmd += ["--mmproj", str(mmproj)]
        on_cpu = cfg["vision"] == "cpu" or (cfg["vision"] == "auto" and (cfg["coexist"] or cfg["tier"] == "medium"))
        if on_cpu and sup("--no-mmproj-offload"): cmd += ["--no-mmproj-offload"]
    if cfg["think"]:
        cmd += ["--chat-template-kwargs", '{"enable_thinking":true}', "--temp", "1.0", "--top-p", "0.95", "--top-k", "20"]
        if sup("--reasoning-budget") and cfg["budget"]: cmd += ["--reasoning-budget", str(cfg["budget"])]
    else:
        cmd += ["--chat-template-kwargs", '{"enable_thinking":false}', "--temp", "0.7", "--top-p", "0.8", "--top-k", "20"]
    cmd += ["--min-p", "0.0", "--alias", "strata-lite"]
    if cfg["api_key"]: cmd += ["--api-key", cfg["api_key"]]
    return cmd, ctx

def port_busy(host, port):
    with socket.socket() as s:
        s.settimeout(0.5); return s.connect_ex(("127.0.0.1" if host in ("0.0.0.0", "") else host, port)) == 0

def health(cfg):
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{cfg['port']}/health", timeout=2) as r: return r.status
    except urllib.error.HTTPError as e: return e.code
    except Exception: return 0

def stop_server():
    pf = RUN / "server.pid"
    if not pf.exists(): return False
    pid = pf.read_text().strip(); pf.unlink()
    if WIN: subprocess.run(["taskkill", "/PID", pid, "/T", "/F"], capture_output=True)
    else: subprocess.run(["kill", pid], capture_output=True)
    return True

def launch(cfg, a):
    exe = server_exe() or die("找不到 llama-server", "运行 START-HERE.bat --setup 重新安装")
    if port_busy(cfg["host"], cfg["port"]): die(f"端口 {cfg['port']} 已被占用", "Strata Lite 可能已经在运行；或用 --port 换一个端口")
    files = cfg["files"]; mdir = MODELS / (cfg["tier"] or "custom")
    model = Path(cfg["gguf"]) if cfg["gguf"] else mdir / files["model"]
    mmproj = (mdir / files["mmproj"]) if cfg["vision"] != "off" and files.get("mmproj") and (mdir / files["mmproj"]).exists() and not cfg["gguf"] else None
    help_text = run([str(exe), "--help"], 30)
    cmd, ctx = build_cmd(cfg, exe, model, mmproj, help_text)
    RUN.mkdir(exist_ok=True); LOGS.mkdir(exist_ok=True)
    log = open(LOGS / "server.log", "w", encoding="utf-8", errors="replace")
    flags = 0x00004000 if WIN else 0                        # 低于正常优先级，不抢前台程序的 CPU
    p = subprocess.Popen(cmd, stdout=log, stderr=subprocess.STDOUT, creationflags=flags, cwd=str(exe.parent))
    (RUN / "server.pid").write_text(str(p.pid))
    say(f"\n[4/4] 正在加载模型（{cfg['tier'] or '自定义'}，上下文 {ctx}，思考{'开' if cfg['think'] else '关'}，看图{'开' if mmproj else '关'}）...")
    t0 = time.time()
    while time.time() - t0 < 300:
        if p.poll() is not None:
            tail = "".join(open(LOGS / "server.log", encoding="utf-8", errors="replace").readlines()[-12:])
            say(tail)
            die("模型启动失败（多半是显存不够）", "试试 --tier small，或 --ctx 4096，或 --vision cpu；完整日志：logs/server.log")
        if health(cfg) == 200: break
        time.sleep(1)
    else:
        die("启动超时", "查看 logs/server.log")
    url = f"http://127.0.0.1:{cfg['port']}"
    g = gpu_info()
    ok(f"就绪，用时 {time.time() - t0:.0f} 秒" + (f"；显存空闲 {g['free']:.1f}/{g['total']:.1f} GB" if g else ""))
    say(f"\n  网页聊天 : {url}\n  API 地址 : {url}/v1   （OpenAI 兼容，任意模型名{'，密钥见 config.json' if cfg['api_key'] else '，任意密钥'}）")
    say(f"  终端聊天 : python chat.py\n  关闭     : 关掉此窗口（或运行 START-HERE.bat --stop）\n")
    if not a.no_browser and cfg["host"] in ("127.0.0.1", "localhost"): webbrowser.open(url)
    try: p.wait()
    except KeyboardInterrupt: pass
    finally:
        p.terminate(); (RUN / "server.pid").unlink(missing_ok=True)

# ---------------------------------------------------------------- 命令
def cmd_status(cfg):
    h = health(cfg)
    say(f"服务状态：{'运行中' if h == 200 else '加载中' if h == 503 else '未运行'}")
    if h:
        try:
            props = http_json(f"http://127.0.0.1:{cfg['port']}/props")
            say(f"  休眠中（已卸载模型）：{props.get('is_sleeping', False)}")
        except Exception: pass
    g = gpu_info()
    if g: say(f"显存：空闲 {g['free']:.1f} / {g['total']:.1f} GB")

def cmd_bench(cfg):
    body = json.dumps({"messages": [{"role": "user", "content": "用中文写一段 200 字的短文，介绍咖啡。"}], "max_tokens": 200, "stream": False}).encode()
    h = {"Content-Type": "application/json"}
    if cfg["api_key"]: h["Authorization"] = "Bearer " + cfg["api_key"]
    try:
        with urllib.request.urlopen(urllib.request.Request(f"http://127.0.0.1:{cfg['port']}/v1/chat/completions", body, h), timeout=300) as r:
            t = json.load(r).get("timings", {})
        say(f"读取提示 {t.get('prompt_per_second', 0):.0f} token/s；生成 {t.get('predicted_per_second', 0):.1f} token/s")
    except Exception as e:
        die(f"测速失败：{e}", "先启动服务")

def cmd_list():
    if not MODELS.exists(): return say("还没有下载任何模型")
    for d in sorted(MODELS.iterdir()):
        if d.is_dir(): say(f"  {d.name:8s} {sum(f.stat().st_size for f in d.glob('*.gguf')) / 2**30:5.2f} GB")

def main():
    ap = argparse.ArgumentParser(description="Strata Lite")
    ap.add_argument("--setup", action="store_true", help="重新回答问题并安装/切换模型")
    ap.add_argument("--check", action="store_true", help="只检测硬件并给出建议")
    ap.add_argument("--update", action="store_true", help="更新 llama.cpp 引擎")
    ap.add_argument("--stop", action="store_true"); ap.add_argument("--status", action="store_true")
    ap.add_argument("--bench", action="store_true"); ap.add_argument("--list", action="store_true")
    ap.add_argument("--remove", metavar="TIER", help="删除某档位已下载的模型")
    ap.add_argument("--yes", "-y", action="store_true", help="全部用推荐值，不提问")
    ap.add_argument("--tier", choices=list(TIERS)); ap.add_argument("--repo", help="自定义 HF GGUF 仓库，如 unsloth/Qwen3.5-9B-GGUF")
    ap.add_argument("--gguf", help="直接使用本地 .gguf 文件")
    ap.add_argument("--ctx", type=int); ap.add_argument("--think", choices=["on", "off"])
    ap.add_argument("--vision", choices=["auto", "gpu", "cpu", "off"]); ap.add_argument("--idle", type=int, help="空闲多少秒后卸载，0=不卸载")
    ap.add_argument("--host"); ap.add_argument("--port", type=int); ap.add_argument("--api-key"); ap.add_argument("--threads", type=int)
    ap.add_argument("--kv", choices=["f16", "q8_0", "q4_0"]); ap.add_argument("--no-browser", action="store_true")
    a = ap.parse_args()
    cfg = load_cfg()
    for k in ("tier", "repo", "gguf", "ctx", "vision", "idle", "host", "port", "api_key", "threads", "kv"):
        v = getattr(a, k, None)
        if v is not None: cfg[k] = v
    if a.think: cfg["think"] = a.think == "on"

    if a.stop: return say("已停止" if stop_server() else "没有在运行的服务")
    if a.status: return cmd_status(cfg)
    if a.bench: return cmd_bench(cfg)
    if a.list: return cmd_list()
    if a.remove:
        shutil.rmtree(MODELS / a.remove, ignore_errors=True); return say(f"已删除 {a.remove}")

    say("=" * 56 + "\n  Strata Lite - 省资源的本地大模型\n" + "=" * 56)
    say("\n[1/4] 检测硬件")
    gpu = gpu_info(); total, avail = ram_gb()
    if gpu: ok(f"GPU：{gpu['name']}，{gpu['total']:.1f} GB 显存（当前空闲 {gpu['free']:.1f} GB），驱动 {gpu['driver']}")
    else: warn("没检测到 NVIDIA 显卡，将使用 Vulkan/CPU 版引擎（更慢）")
    ok(f"内存：{total:.0f} GB（当前可用 {avail:.1f} GB）；CPU 线程：{os.cpu_count()}")
    if a.check:
        rec = recommend(gpu, False); rec2 = recommend(gpu, True)
        say(f"\n  推荐：独占运行 -> {rec}；与 ComfyUI 同开 -> {rec2}\n  这台机器跑不了 Strata 原版（需要 40GB+ 内存），但完全能跑 Strata Lite。")
        return
    first = not cfg["files"] and not cfg["gguf"]
    if first or a.setup or a.tier or a.repo:
        if first or a.setup: interview(cfg, gpu, a)
        cfg["tier"] = cfg["tier"] or ("custom" if cfg["repo"] else recommend(gpu, cfg["coexist"]))
        say("\n[3/4] 安装引擎和模型")
        ensure_engine(gpu, force=a.update)
        if not cfg["gguf"]:
            repo = cfg["repo"] or TIERS[cfg["tier"]]["repo"]
            files = hf_files(repo)
            m, mp = pick_gguf(files), pick_mmproj(files)
            if not m: die(f"仓库 {repo} 里没有 Q4 量化的 GGUF")
            mdir = MODELS / cfg["tier"]
            download(f"{HF}/{repo}/resolve/main/{m}", mdir / m, files[m], m[:34])
            if mp and cfg["vision"] != "off": download(f"{HF}/{repo}/resolve/main/{mp}", mdir / mp, files[mp], mp[:34])
            cfg["files"] = {"model": m, "mmproj": mp if cfg["vision"] != "off" else None}
        save_cfg(cfg); ok("安装完成，设置已保存到 config.json")
    else:
        ensure_engine(gpu, force=a.update)
    save_cfg(cfg)
    launch(cfg, a)

if __name__ == "__main__":
    main()
