#!/usr/bin/env python3
"""Strata Lite 的极简终端聊天客户端（纯标准库，流式输出）。"""
import json, sys, urllib.request
from pathlib import Path

CFG = json.loads((Path(__file__).parent / "config.json").read_text(encoding="utf-8")) if (Path(__file__).parent / "config.json").exists() else {}
URL = f"http://127.0.0.1:{CFG.get('port', 8080)}/v1/chat/completions"

def stream(messages):
    h = {"Content-Type": "application/json"}
    if CFG.get("api_key"): h["Authorization"] = "Bearer " + CFG["api_key"]
    body = json.dumps({"model": "strata-lite", "messages": messages, "stream": True}).encode("utf-8")
    req = urllib.request.Request(URL, body, h)
    try:
        with urllib.request.urlopen(req, timeout=300) as r:
            out = ""
            for line in r:
                line = line.decode("utf-8", "replace").strip()
                if not line.startswith("data: "): continue
                chunk = line[6:]
                if chunk == "[DONE]": break
                delta = json.loads(chunk)["choices"][0]["delta"].get("content", "")
                if delta: print(delta, end="", flush=True); out += delta
            print()
            return out
    except Exception as e:
        print(f"\n[连接失败：{e}] 先运行 START-HERE.bat 启动服务")
        sys.exit(1)

def main():
    print("Strata Lite 终端聊天（输入 /exit 退出，/reset 清空上下文）\n")
    history = []
    while True:
        try:
            u = input("你: ").strip()
        except (EOFError, KeyboardInterrupt):
            break
        if not u: continue
        if u == "/exit": break
        if u == "/reset": history = []; print("[已清空上下文]"); continue
        history.append({"role": "user", "content": u})
        print("AI: ", end="")
        reply = stream(history)
        history.append({"role": "assistant", "content": reply})

if __name__ == "__main__":
    main()
