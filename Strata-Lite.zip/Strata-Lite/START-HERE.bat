@echo off
title Strata Lite
cd /d "%~dp0"

set PYCMD=
python --version >nul 2>nul
if not errorlevel 1 set PYCMD=python
if "%PYCMD%"=="" (
    py --version >nul 2>nul
    if not errorlevel 1 set PYCMD=py
)

if "%PYCMD%"=="" (
    echo Python not found. Opening the download page...
    echo IMPORTANT: during install, check "Add python.exe to PATH"
    start https://www.python.org/downloads/
    pause
    exit /b 1
)

%PYCMD% setup.py %*
if errorlevel 1 pause
