# Strata Lite

给 **8GB 显存 / 16GB 内存** 笔记本做的轻量本地大模型启动器。
原版 Strata 跑的是 125B 大模型，需要 40GB+ 内存，这台机器带不动；
Strata Lite 改用 Qwen3.5 系列小模型（2B / 4B / 9B），4-bit 量化，
显存占用 1.5–7GB，聊天、写作、编程、看图都支持，还能和 ComfyUI 同时开。

## 使用方法

1. 双击 **START-HERE.bat**
2. 首次运行会问几个问题（是否要和 ComfyUI 同开、要不要看图、多久没用自动释放显存……），
   然后自动下载引擎和模型（几分钟到十几分钟，取决于网速）
3. 自动打开网页聊天界面：`http://127.0.0.1:8080`
4. 以后双击 START-HERE.bat 就直接启动，不会再问

同时也提供兼容 OpenAI 的接口地址：`http://127.0.0.1:8080/v1`，
可以填进 ComfyUI 的 LLM 节点、沉浸式翻译、Cherry Studio 等任何支持 OpenAI 接口的软件。

终端聊天：双击后另开一个窗口运行 `python chat.py`
关闭服务：双击 **STOP.bat**（或直接关掉运行窗口）

## 三档模型

| 档位 | 参数量 | 显存占用 | 适合 |
|---|---|---|---|
| mini | 2B | 约1.5GB | 边跑 ComfyUI 边聊天，几乎不占资源 |
| small | 4B | 约3GB | 日常使用，兼顾速度和质量（默认推荐） |
| medium | 9B | 约6-7GB | 追求最强效果，独占显卡时用 |

三档都原生支持看图（图片理解），可以随时切换、重新下载：
```
START-HERE.bat --setup          交互式重新设置（换档位/开关看图等）
START-HERE.bat --tier medium    直接切到 9B 档
START-HERE.bat --tier mini -y   切到 2B 档，不询问，用默认值
```

## 常用参数

```
--check            只检测硬件，给出建议档位，不下载不启动
--vision cpu        看图计算放 CPU（省显存，速度慢一点，适合和 ComfyUI 同开）
--vision off         关闭看图功能，省内存
--think on / off     开关思考模式（更聪明但更慢）
--idle 300           5 分钟没人用自动卸载模型、释放显存；0 = 常驻不卸载
--ctx 4096           改上下文长度（默认按档位自动选）
--repo <hf仓库>      用别的模型，比如 --repo unsloth/Qwen3.5-14B-A3B-GGUF
--status             查看当前是否在运行、显存占用
--bench              测一下当前生成速度
--list               看看已下载了哪些档位，占多少硬盘
--remove mini        删除某个档位的模型文件
--update             更新 llama.cpp 引擎到最新版
```

## 省资源的关键设计

- **闲时自动睡眠**：空闲一段时间自动把模型从内存/显存卸载，占用降到几乎为零，
  下次提问自动重新加载（几秒钟）。
- **KV 缓存量化**：默认用 q8_0 压缩对话上下文占用的显存，多轮对话更省显存。
- **看图可选放 CPU**：开着 ComfyUI 时，图片理解部分可以选择用 CPU 算，把显存都留给 ComfyUI。
- **低进程优先级**：Strata Lite 不会抢占你正在用的其它程序的 CPU。
- **单文件量化模型**：4-bit GGUF 格式，硬盘占用只有原模型的四分之一左右。

## 文件说明

```
Strata-Lite/
├── START-HERE.bat   启动
├── STOP.bat         停止
├── setup.py         主程序
├── chat.py          终端聊天客户端
├── config.json       你的设置（自动生成）
├── engine/           llama.cpp 引擎（自动下载）
├── models/           模型文件（自动下载）
│   ├── mini/small/medium/...
└── logs/server.log   运行日志，出问题时看这个
```

## 常见问题

**下载很慢/卡住**：设置环境变量 `HF_ENDPOINT=https://hf-mirror.com` 后重新运行，会自动断点续传。

**启动失败提示显存不够**：换小一档，或加 `--ctx 4096` 降低上下文，或 `--vision off` 关闭看图。

**想同时开 ComfyUI**：设置时选"需要同开"，会自动推荐更小的档位、
并可以把看图计算放到 CPU（`--vision cpu`）。

**杀毒软件报警**：是 Windows 对新下载可执行文件的正常提示（llama.cpp 官方引擎），
选择"仍要运行"即可，源码在 [ggml-org/llama.cpp](https://github.com/ggml-org/llama.cpp)。
