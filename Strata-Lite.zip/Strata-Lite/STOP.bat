@echo off
cd /d "%~dp0"

set PYCMD=
python --version >nul 2>nul
if not errorlevel 1 set PYCMD=python
if "%PYCMD%"=="" (
    py --version >nul 2>nul
    if not errorlevel 1 set PYCMD=py
)
if "%PYCMD%"=="" (
    echo Python not found.
    pause
    exit /b 1
)

%PYCMD% setup.py --stop
pause
